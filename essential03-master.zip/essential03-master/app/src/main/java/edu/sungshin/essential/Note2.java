package edu.sungshin.essential;

public class Note2 {
    int _id2;
    String todo2;

    public Note2(int _id2, String todo2){
        this._id2 = _id2;
        this.todo2 = todo2;
    }

    public int get_id2() {
        return _id2;
    }

    public void set_id2(int _id2) {
        this._id2 = _id2;
    }

    public String getTodo2() {
        return todo2;
    }

    public void setTodo2(String todo2) {
        this.todo2 = todo2;
    }
}