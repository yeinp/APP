package edu.sungshin.essential;

public class User {

    private String Title;
    private String Subtitle;

    public User(){}


    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getSubtitle() {
        return Subtitle;
    }

    public void setSubtitle(String subtitle) {
        Subtitle = subtitle;
    }
}